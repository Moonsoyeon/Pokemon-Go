import React from 'react';

export default function Coupon (){

    return(
        <div style = {{
        }}><img src="https://storage.googleapis.com/nianticweb-branding/niantic/niantic-horizontal-black.svg"></img></div>

    )

} 